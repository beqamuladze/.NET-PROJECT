﻿using Domain.Models;
using Services.Abstractions;
using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using Services.Implementations;

namespace Controllers
{
	[Route("api/[controller]")]
	[ApiController]
	public class ProductsController : ControllerBase
	{
		public IProductService _productService;

		public ProductsController(IProductService productService)
		{
            _productService = productService;
		}

		[HttpGet("GetAllProducts")]
		public async Task<List<Product>> GetAllProducts()
		{
			var products = await _productService.GetAllProducts();

			return products;
		}

        [HttpGet("GetProductById/{id}")]
        public Product GetProductById(int id)
        {
            var product =  _productService.GetProductById(id);

            return product;
        }

        [HttpPost("AddProduct")]
		public async Task<Product> AddProduct(Product product)
		{
			var addedProduct = await _productService.AddProduct(product);

			return addedProduct;
		}

		[HttpPut("UpdateProduct/{id}")]
		public Product UpdateProduct(int id, Product product)
		{
			var newProduct = _productService.UpdateProduct(id, product);

			return newProduct;
		}

		[HttpDelete("DeleteProduct/{id}")]
		public Product DeleteProduct(int id)
		{
			var deletedProduct = _productService.DeleteProduct(id);

			return deletedProduct;
		}

        [HttpGet("GetProductsByCategoryId/{categoryId}")]
        public async Task<List<Product>> GetProductsByCategoryId(int categoryId)
        {
            var productsInCategory = await _productService.GetProductsByCategoryId(categoryId);

            return productsInCategory;
        }

        [HttpGet("GetTotalPriceByCategoryId/{categoryId}")]
        public IActionResult GetTotalPriceByCategoryId(int categoryId)
        {
            var totalPrice = _productService.GetTotalPriceByCategoryId(categoryId);

            return Ok(totalPrice);
        }

        [HttpGet("GetTotalPricePerCategory")]
        public IActionResult GetTotalPricePerCategory()
        {
            var totalPricePerCategory = _productService.GetTotalPricePerCategory();

            return Ok(totalPricePerCategory);
        }
    }
}
